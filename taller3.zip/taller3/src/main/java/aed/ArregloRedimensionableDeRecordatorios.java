package aed;

class ArregloRedimensionableDeRecordatorios implements SecuenciaDeRecordatorios {

    public ArregloRedimensionableDeRecordatorios() {
        throw new UnsupportedOperationException("No implementada aun");
    }

    public ArregloRedimensionableDeRecordatorios(ArregloRedimensionableDeRecordatorios vector) {
        throw new UnsupportedOperationException("No implementada aun");
    }

    public int longitud() {
        throw new UnsupportedOperationException("No implementada aun");
    }

    public void agregarAtras(Recordatorio i) {
        throw new UnsupportedOperationException("No implementada aun");
    }

    public Recordatorio obtener(int i) {
        throw new UnsupportedOperationException("No implementada aun");
    }

    public void quitarAtras() {
        throw new UnsupportedOperationException("No implementada aun");
    }

    public void modificarPosicion(int indice, Recordatorio valor) {
        throw new UnsupportedOperationException("No implementada aun");

    }

    public ArregloRedimensionableDeRecordatorios copiar() {
        throw new UnsupportedOperationException("No implementada aun");
    }

}
